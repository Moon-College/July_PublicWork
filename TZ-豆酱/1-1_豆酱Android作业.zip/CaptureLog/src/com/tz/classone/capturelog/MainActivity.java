package com.tz.classone.capturelog;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import com.tz.classone.R;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;


public class MainActivity extends Activity implements OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        findViewById(R.id.button1).setOnClickListener(this);
        findViewById(R.id.button2).setOnClickListener(this);
    }

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.button1:
			try {
				captureLog();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case R.id.button2:
			callMe();
			break;

		default:
			break;
		}
	}
	
	private void captureLog() throws IOException {
		Log.i("INFO", "HELLO BABY");
		List<String> list=new ArrayList<String>();
		list.add("logcat");
		list.add("-d");
		list.add("-s");
		list.add("INFO");
		
		Process exec = Runtime.getRuntime().exec(list.toArray(new String[list.size()]));
		
		InputStream in = exec.getInputStream();
		BufferedReader br=new BufferedReader(new InputStreamReader(in));
		
		StringBuffer buffer=new StringBuffer();
		
		String str=null;
		while ((str=br.readLine())!=null) {
//			Runtime.getRuntime().exec(clearLog.toArray(new String[clearLog.size()]));  //������־....����������Ҫ���������Ļ����κβ������������µ���־�����������ѭ����ֱ��bufferreader��
			
			buffer.append(str);
			buffer.append("\n");
		}
		Toast.makeText(getApplicationContext(), buffer.toString(), 1).show();
	}
	
	private void callMe(){
		Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse("tel:10010"));
		startActivity(intent);
	}
}
