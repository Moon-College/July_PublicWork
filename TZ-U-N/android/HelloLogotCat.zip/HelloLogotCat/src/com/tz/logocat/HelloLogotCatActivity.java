package com.tz.logocat;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;
public class HelloLogotCatActivity extends Activity implements OnClickListener {
	private Button log;//
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
    // Log.i("MY INFo", " onCreate ,����App����");
    // Log.i("MY WARN", " ���������˽�");
     initView();
     
    
    }

	private void initView() {
		// init button by id ��ʼ����ťͨ��id
		log =(Button) findViewById(R.id.log);
		//set listener
		log.setOnClickListener(this);
	}

	public void onClick(View arg0) {
			// connect logs
		try {
			readLog();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
	}

	private void readLog() throws IOException {
		// TODO Auto-generated method stub
		Log.i("SB","������Ҫ�����д����");
	
		StringBuffer sb = new StringBuffer();
		ArrayList<String>cmdLine = new ArrayList<String>();
		cmdLine.add("logcat");
		cmdLine.add("-d");//ֻ�ɼ�һ��
		cmdLine.add("-s");//����
		cmdLine.add("SB");
	//	cmdLine.add("*��e");//�鿴����warm����־
		Process exec = Runtime.getRuntime().exec(cmdLine.toArray(new String[cmdLine.size()]));
		InputStream inputStream = exec.getInputStream(); 
		InputStreamReader isReader = new InputStreamReader(inputStream);
		BufferedReader reader = new BufferedReader(isReader);
		String str = null;
		while((str =reader.readLine()) != null){
			sb.append(str);
			sb.append("\n");
			
		}
		Toast.makeText(this, sb.toString(),2).show();
	
	}
}