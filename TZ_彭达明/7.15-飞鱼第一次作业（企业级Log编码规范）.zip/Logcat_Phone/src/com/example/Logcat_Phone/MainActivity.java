package com.example.Logcat_Phone;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
public class MainActivity extends Activity {
	private EditText etTel;
	private TextView tvLog;
	public void loadView(){
		etTel=(EditText)findViewById(R.id.etTel);
		tvLog=(TextView) findViewById(R.id.tv_log);
	}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.activity_main);
		super.onCreate(savedInstanceState);
		loadView();
	}
	
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btn1:
			savaDebug();
			break;
		case R.id.btn2:
			Intent intent=new Intent(Intent.ACTION_DIAL,Uri.parse("tel:" + etTel.getText()));
			startActivity(intent);
			Log.i("info", "��Ѵ�绰����");
			break;	
		default:
			break;
	}
}
	private void savaDebug() {
		ArrayList<String> cmdLine = new ArrayList<String>();
		cmdLine.add("logcat");
		cmdLine.add("-d");
		cmdLine.add("-s");
		cmdLine.add("info");
		try {
			Process exec = Runtime.getRuntime().exec(cmdLine.toArray(new String[cmdLine.size()]));
			InputStream in=exec.getInputStream();
			BufferedInputStream is=new BufferedInputStream(in);
			OutputStream out=new ByteArrayOutputStream();
			byte[] buffer=new byte[1024];
			int len=0;
			while ((len=is.read(buffer))!=-1) {
				out.write(buffer,0,len);
			}
			tvLog.setText(out.toString());
			Toast.makeText(this, out.toString(), Toast.LENGTH_LONG).show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
