package com.wyk.tz_1_log.ui;

import com.wyk.tz_1_log.R;
import com.wyk.tz_1_log.R.layout;
import com.wyk.tz_1_log.R.menu;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;

public class TelephoneActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_telephone);
	}


}
