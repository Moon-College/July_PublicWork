package com.wyk.tz_1_log.ui;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.wyk.tz_1_log.R;

/**
 * 
 * 此类描述的是: 程序主入口
 * 
 * @author: Kirk.WangYangke
 * @version:1.0
 * @date:2015-7-15 下午11:19:45
 */
public class MainActivity extends Activity {
	/** 显示的日志文本 */
	private TextView log_message_tv;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	/**
	 * 
	 * 此方法描述的是：跳转到打电话
	 * 
	 * @param view
	 */
	public void gotoPhone(View view) {
		startActivity(new Intent(this, TelephoneActivity.class));
	}

	/**
	 * 
	 * 此方法描述的是：跳转到发送短信
	 * 
	 * @param view
	 */
	public void gotoSms(View view) {
		startActivity(new Intent(this, SmsActivity.class));
	}

	/**
	 * 
	 * 此方法描述的是：打印日志
	 * 
	 * @param view
	 */
	public void showLog(View view) {
		log_message_tv = (TextView) findViewById(R.id.log_message_tv);
		ArrayList<String> cmdLine = new ArrayList<String>();
		cmdLine.add("logcat");
		cmdLine.add("-d");
		cmdLine.add("-s");
		cmdLine.add("info");
		try {
			Process exec = Runtime.getRuntime().exec(
					cmdLine.toArray(new String[cmdLine.size()]));
			InputStream in = exec.getInputStream();
			BufferedInputStream is = new BufferedInputStream(in);
			OutputStream out = new ByteArrayOutputStream();
			byte[] buffer = new byte[1024];
			int len = 0;
			while ((len = is.read(buffer)) != -1) {
				out.write(buffer, 0, len);
			}
			log_message_tv.setText(out.toString());
			Toast.makeText(this, out.toString(), Toast.LENGTH_LONG).show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
