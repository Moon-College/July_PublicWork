package com.wyk.tz_1_log.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

import com.wyk.tz_1_log.R;

public class SmsActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_sms);
	}
	public void sendSms(View view){
		
	}


}
