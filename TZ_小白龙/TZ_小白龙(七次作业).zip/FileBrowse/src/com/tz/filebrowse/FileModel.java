package com.tz.filebrowse;

import android.graphics.Bitmap;

public class FileModel {
	
	private String fileName;
	
	private Bitmap bitmap;
	
	private String filePath;
	
	private boolean isThumb;
	
	public FileModel(){
	}
	
	public FileModel(String fileName,Bitmap bitmap,String filePath,boolean isThumb){
		this.fileName = fileName;
		this.bitmap = bitmap;
		this.filePath = filePath;
		this.isThumb = isThumb;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Bitmap getBitmap() {
		return bitmap;
	}

	public void setBitmap(Bitmap bitmap) {
		this.bitmap = bitmap;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public boolean isThumb() {
		return isThumb;
	}

	public void setThumb(boolean isThumb) {
		this.isThumb = isThumb;
	}
	
	

}
