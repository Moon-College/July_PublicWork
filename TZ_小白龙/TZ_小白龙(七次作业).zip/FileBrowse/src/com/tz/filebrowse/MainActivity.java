package com.tz.filebrowse;

import java.io.File;
import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.UriMatcher;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends Activity {

	private ListView listview;
	private String rootPath;
	private ArrayList<FileModel> mList;
	private Bitmap fileBitmap, audioBitmap, videoBitmap, txtBitmap;
	private FileAdapter adapter;
	private String[] array = new String[] { "删除", "打开" };

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		listview = (ListView) findViewById(R.id.listview);
		initPath();
	}

	private void createBitmap() {
		fileBitmap = BitmapFactory.decodeResource(getResources(),
				R.drawable.format_folder);
		audioBitmap = BitmapFactory.decodeResource(getResources(),
				R.drawable.format_music);
		videoBitmap = BitmapFactory.decodeResource(getResources(),
				R.drawable.format_media);
		txtBitmap = BitmapFactory.decodeResource(getResources(),
				R.drawable.format_text);
	}

	private void initPath() {
		// sd卡 挂载成功
		if (Environment.getExternalStorageState().equals(
				Environment.MEDIA_MOUNTED)) {
			createBitmap();
			rootPath = Environment.getExternalStorageDirectory()
					.getAbsolutePath();
			mList = new ArrayList<FileModel>();
			readPath(rootPath);
			initEvent();
		} else {
			Toast.makeText(this, "您的sd卡挂载异常", Toast.LENGTH_SHORT).show();
		}
	}

	private void initEvent() {
		listview.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1,
					int postion, long arg3) {
				FileModel model = mList.get(postion);
				File file = new File(model.getFilePath());
				if (file.isDirectory()) {
					readPath(file.getAbsolutePath());
				}
			}
		});
		listview.setOnItemLongClickListener(new OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
					int postion, long arg3) {
				if (postion != 0) {
					FileModel model = mList.get(postion);
					File file = new File(model.getFilePath());
					showDialog(file);
				}
				return false;
			}
		});
	}

	/**
	 * 遍历文件
	 */
	private void readPath(String filePath) {
		mList.clear();
		File file = new File(filePath);

		String parent = null;
		if (file.getAbsolutePath().equals(rootPath)) {
			parent = rootPath;
		} else {
			parent = file.getParent();
		}
		FileModel modelBack = new FileModel("返回上级", fileBitmap, parent, false);
		mList.add(modelBack);

		File[] fileArray = file.listFiles();

		for (File fileItem : fileArray) {
			FileModel model = new FileModel();
			String fileName = fileItem.getName();
			model.setFileName(fileName);
			model.setFilePath(fileItem.getAbsolutePath());

			// 如果是文件夹
			fileName = fileName.toLowerCase();
			if (fileItem.isDirectory()) {
				model.setBitmap(fileBitmap);
				model.setThumb(false);
			} else if (fileName.endsWith(".png") || fileName.endsWith(".jpg")
					|| fileName.endsWith(".png")) {
				model.setThumb(true);
				model.setBitmap(null);
			} else if (fileName.equals(".mp3")) {
				model.setThumb(false);
				model.setBitmap(audioBitmap);
			} else if (fileName.equals(".mp4")) {
				model.setThumb(false);
				model.setBitmap(videoBitmap);
			} else {
				model.setThumb(false);
				model.setBitmap(txtBitmap);
			}
			mList.add(model);
		}
		adapter = new FileAdapter(this, mList);
		listview.setAdapter(adapter);
	}

	public void showDialog(final File file) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("选择对文件的操作");
		builder.setSingleChoiceItems(array, 0,
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface arg0, int what) {
						switch (what) {
						case 0:
							String path = file.getParent();
							delete(file);
							readPath(path);
							break;
						case 1:
							if(file.isDirectory()){
								
							}else{
								Intent intent = new Intent();
								intent.setAction(Intent.ACTION_VIEW);// 发送信息的动作
								intent.addCategory("android.intent.category.DEFAULT");// 附加信息
								Uri uri = Uri.fromFile(file);
								intent.setData(uri);// 具体的数据，发送给10086
								startActivity(intent);
							}
							break;
						}
					}
				});
		builder.show();
	}

	public void delete(File file) {
		if (file.isFile()) {
			file.delete();
			return;
		}
		if (file.isDirectory()) {
			File[] childFiles = file.listFiles();
			if (childFiles == null || childFiles.length == 0) {
				file.delete();
				return;
			}

			for (int i = 0; i < childFiles.length; i++) {
				delete(childFiles[i]);
			}
			file.delete();
		}
	}

}
