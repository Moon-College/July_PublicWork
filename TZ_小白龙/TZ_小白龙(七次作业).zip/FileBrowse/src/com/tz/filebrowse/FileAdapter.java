package com.tz.filebrowse;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class FileAdapter extends BaseAdapter{

	private ArrayList<FileModel> mList;
	private LayoutInflater inflater;
	private ImageLoader imageLoader;
	
	public FileAdapter(Context context,ArrayList<FileModel> list){
		inflater = LayoutInflater.from(context);
		mList = list;
		imageLoader = ImageLoader.getInstance();
	}
	
	@Override
	public int getCount() {
		return mList.size();
	}

	@Override
	public Object getItem(int position) {
		return mList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if(convertView == null){
			convertView = inflater.inflate(R.layout.file_item, null);
			holder = new ViewHolder();
			holder.img = (ImageView) convertView.findViewById(R.id.img);
			holder.tv_name = (TextView) convertView.findViewById(R.id.tv_name);
			convertView.setTag(holder);
		}else{
			holder = (ViewHolder) convertView.getTag();
		}
		FileModel model = mList.get(position);
		holder.tv_name.setText(model.getFileName());
		if(model.getBitmap() == null){
			LoadFileAsyncTask asyncTask = new LoadFileAsyncTask(holder.img);
			asyncTask.execute(model.getFilePath());
		}
		holder.img.setImageBitmap(model.getBitmap());
		return convertView;
	}
	
	class ViewHolder{
		ImageView img;
		TextView tv_name;
	}
	
	
	class LoadFileAsyncTask extends AsyncTask<String, Void, Void>{
		
		private ImageView iv;
		private Bitmap bitmap;
		
		public LoadFileAsyncTask(ImageView iv){
			this.iv = iv;
		}
		
		@Override
		protected Void doInBackground(String... params) {
			String path = params[0];
			bitmap = imageLoader.getBitmapFromMemoryCache(path);
			if(null == bitmap){
				bitmap = ImageLoader.decodeBitmapFromResource(path, 100);
				imageLoader.addBitmapToMemoryCache(path, bitmap);
			}
			return null;
		}
		
		@Override
		protected void onPostExecute(Void result) {
			super.onPostExecute(result);
			iv.setImageBitmap(bitmap);
		}
	}
	
}
