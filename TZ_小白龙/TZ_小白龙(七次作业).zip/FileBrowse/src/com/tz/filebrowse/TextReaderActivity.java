package com.tz.filebrowse;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;

public class TextReaderActivity extends Activity{
	
	private TextView textView;
	private String path;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.text_reader);
		textView = (TextView) findViewById(R.id.tv_info);
		Intent intent = this.getIntent();
		Uri data = intent.getData();
		path = data.getPath();
		openFile();
	}

	private void openFile() {
		try{
		File file = new File(path);
		FileInputStream is = new FileInputStream(file);
		ByteArrayOutputStream bao = new ByteArrayOutputStream();
		int len = 0;
		byte[] buffer = new byte[1024];
		while((len=is.read(buffer))!=-1){
			bao.write(buffer, 0, len);
		}
		textView.setText(bao.toString());
		bao.close();
		is.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
