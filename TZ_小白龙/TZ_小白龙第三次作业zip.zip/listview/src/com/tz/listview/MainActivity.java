package com.tz.listview;

import java.util.ArrayList;
import java.util.List;

import android.os.Bundle;
import android.widget.ListView;
import android.app.Activity;

public class MainActivity extends Activity {
	
	private ListView listview;
	private MyAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        initView();
    }

	private void initView() {
		listview = (ListView) findViewById(R.id.listview);
		adapter = new MyAdapter(this, getListData());
		listview.setAdapter(adapter);
	}
	
	private List<PersonModel> getListData(){
		List<PersonModel> list = new ArrayList<PersonModel>();
		PersonModel model = null;
		for(int i = 0; i < 10; i++){
			model = new PersonModel();
			model.setName("第"+i+"个老师");
			model.setHobby("爱好是买"+i+"个iPhone手机");
			model.setSex(i%2);
			list.add(model);
		}
		return list;
	}

    
}
