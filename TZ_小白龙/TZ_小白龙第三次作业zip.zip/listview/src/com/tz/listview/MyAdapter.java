package com.tz.listview;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class MyAdapter extends BaseAdapter{
	
	private List<PersonModel> list;
	private LayoutInflater inflater;
	
	public MyAdapter(Context context,List<PersonModel> list){
		this.list = list;
		inflater = LayoutInflater.from(context);
	}

	@Override
	public int getCount() {
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder = null;
		if(convertView == null){
			 convertView = inflater.inflate(R.layout.item, null);
			 holder = new ViewHolder();
			 holder.txSex =  (TextView) convertView.findViewById(R.id.tv_sex);
			 holder.txName=  (TextView) convertView.findViewById(R.id.name);
			 holder.txHobby =  (TextView) convertView.findViewById(R.id.hobby);
			 convertView.setTag(holder);
		}else{
			 holder = (ViewHolder) convertView.getTag();
		}
		PersonModel model = list.get(position);
		holder.txName.setText(model.getName());
		if(model.getSex()==1){
			holder.txSex.setText("男");
			holder.txSex.setTextColor(android.graphics.Color.BLUE);
		}else{
			holder.txSex.setText("女");
			holder.txSex.setTextColor(android.graphics.Color.RED);
		}
		holder.txHobby.setText(model.getHobby());
		return convertView;
	}
	
	class ViewHolder {
		TextView txName;
		TextView txSex;
		TextView txHobby;
	}

}
