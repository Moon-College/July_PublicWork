package com.tz.mylog;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {

	private Button btn_call,btn_log,btn_msg;
	private EditText phone_number;
	private ArrayList<String> list;
	private String logPath = Environment.getExternalStorageDirectory()+File.separator+"mylog";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		initView();//��ʼ��view
	}
	
	Handler mHandler = new Handler(){
		@Override
		public void dispatchMessage(Message msg) {
			super.dispatchMessage(msg);
			if(msg.what == 0){
				Toast.makeText(MainActivity.this,"�ռ�log�ѳɹ�����",Toast.LENGTH_SHORT).show();
			}
		}
	};
	
	private void initView(){
		//��ȡview ID 
		 btn_call = (Button) findViewById(R.id.call_phone);
		 btn_log = (Button) findViewById(R.id.savelog);
		 btn_msg = (Button) findViewById(R.id.send_msg);
		 phone_number = (EditText) findViewById(R.id.phone_number);
		 //���ü���
		 btn_call.setOnClickListener(this);
		 btn_log.setOnClickListener(this);
		 btn_msg.setOnClickListener(this);
		 //��ʼ������
		 list = new ArrayList<String>();
		 
		 File file = new File(logPath);
		 if(!file.exists()){
			 file.mkdir();//��� sd��Ŀ¼�µ��ļ� ������ ��ô�ȴ���
		 }
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.savelog:
			saveLog();
			break;
		case R.id.call_phone:
			callPhone();
			break;
		case R.id.send_msg:
			sendMsg();
			break;
		}
	}
	
	/**
	 * �������log
	 * @author С����-�Ϻ�
	 * QQ:416603734
	 */
	private void saveLog(){
		Toast.makeText(MainActivity.this,"��ʼ�ռ�log����...",Toast.LENGTH_SHORT).show();
		list.clear();
		createLogInfo();
		list.add("logcat");
		list.add("-d");//ֻ�ռ�һ��
		list.add("-s");//����
		list.add("MY_TAG");//����
		new Thread(runnable).start();
	}
	
	Runnable runnable = new Runnable() {
		@Override
		public void run() {
			try {
				Process process = Runtime.getRuntime().exec(list.toArray(new String[list.size()]));
				InputStream is = process.getInputStream();
				FileOutputStream fos = new FileOutputStream(logPath+File.separator+"log.txt");
				byte[] b = new byte[1024*5];
				while((is.read(b)) != -1){
					fos.write(b);
				}
				is.close();
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			mHandler.sendEmptyMessage(0);
		}
	};
	
	/**
	 * ����log��Ϣ 
	 * @author С����-�Ϻ�
	 * QQ:416603734
	 */
	private void createLogInfo(){
		Log.v("MY_TAG","this is verbose");//verbose
		Log.d("MY_TAG","this is debug");//debug
		Log.i("MY_TAG","this is info");//info
		Log.w("MY_TAG","this is warn");//warn
		Log.e("MY_TAG","this is error");//error
	}
	
	/**
	 * �������绰
	 * @author С����-�Ϻ�
	 * QQ:416603734
	 */
	private void callPhone(){
		String phone = phone_number.getText().toString();
		if(phone.equals("")){
			Toast.makeText(this,"�绰���벻��Ϊ��", Toast.LENGTH_SHORT).show();
			return;
		}
		Intent intent = new Intent(Intent.ACTION_CALL,Uri.parse("tel:"+phone));
		startActivity(intent);
	}
	
	/**
	 * ������Ͷ���
	 * @author С����-�Ϻ�
	 * QQ:416603734
	 */
	private void sendMsg(){
		String phone = phone_number.getText().toString();
		if(phone.equals("")){
			Toast.makeText(this,"�绰���벻��Ϊ��", Toast.LENGTH_SHORT).show();
			return;
		}
		Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"+phone));            
        intent.putExtra("sms_body","������Ҫ���͵Ķ�������Ŷ");            
        startActivity(intent);  
	}
}
