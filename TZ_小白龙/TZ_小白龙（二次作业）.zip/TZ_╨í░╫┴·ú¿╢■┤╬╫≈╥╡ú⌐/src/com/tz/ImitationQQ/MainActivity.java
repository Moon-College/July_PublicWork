package com.tz.ImitationQQ;


import java.util.ArrayList;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

public class MainActivity extends FragmentActivity {
	
	private ArrayList<Fragment> pagerItemList = null;
	private ImageView img_1,img_2,img_3;
	private int currIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        initFragment();
    }

	private void initFragment() {
		Fragment1 page1 = new Fragment1();
		Fragment2 page2 = new Fragment2();
		Fragment3 page3 = new Fragment3();
		pagerItemList = new ArrayList<Fragment>();
		pagerItemList.add(page1);
		pagerItemList.add(page2);
		pagerItemList.add(page3);
		
		img_1 = (ImageView) findViewById(R.id.img_1);
		img_1.setImageResource(R.drawable.skin_tab_icon_conversation_selected);
		img_2 = (ImageView) findViewById(R.id.img_2);
		img_3 = (ImageView) findViewById(R.id.img_3);
		
		currIndex = 0;
		FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
		ft.add(R.id.tab_content, pagerItemList.get(0));
		ft.commit();
		initEvent();
	}

	private void initEvent() {
		img_1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				selectChanged(0);
				img_1.setImageResource(R.drawable.skin_tab_icon_conversation_selected);
				img_2.setImageResource(R.drawable.skin_tab_icon_contact_normal);
				img_3.setImageResource(R.drawable.skin_tab_icon_plugin_normal);
				}
			});
		img_2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				selectChanged(1);
				img_1.setImageResource(R.drawable.skin_tab_icon_conversation_normal);
				img_2.setImageResource(R.drawable.skin_tab_icon_contact_selected);
				img_3.setImageResource(R.drawable.skin_tab_icon_plugin_normal);
			}
		});
		img_3.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				selectChanged(2);
				img_1.setImageResource(R.drawable.skin_tab_icon_conversation_normal);
				img_2.setImageResource(R.drawable.skin_tab_icon_contact_normal);
				img_3.setImageResource(R.drawable.skin_tab_icon_plugin_selected);
			}
		});		
	}
	
	protected void selectChanged(int index) {
		Fragment fragment = pagerItemList.get(index);
		FragmentTransaction ft = obtainFragmentTransaction(index);
		getCurrentFragment().onPause(); 
		if (fragment.isAdded()) {
			fragment.onResume();
		} else {
			ft.add(R.id.tab_content, fragment);
		}
		showTab(index);
		ft.commit();
	}
	
	public class MyOnClickListener implements OnClickListener{
		
		public MyOnClickListener(int i){
			currIndex = i;
		}

		@Override
		public void onClick(View v) {
			showTab(currIndex);
		}
	}
	
	public Fragment getCurrentFragment() {
		return pagerItemList.get(currIndex);
	}
	
	
	private void showTab(int idx) {
		for (int i = 0; i < pagerItemList.size(); i++) {
			Fragment fragment = pagerItemList.get(i);
			FragmentTransaction ft = obtainFragmentTransaction(idx);
			if (idx == i) {
				ft.show(fragment);
			} else {
				ft.hide(fragment);
			}
			ft.commit();
		}
		currIndex = idx; 
	}
	
	private FragmentTransaction obtainFragmentTransaction(int index) {
		FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
		if (index > currIndex) {
			ft.setCustomAnimations(R.anim.slide_left_in, R.anim.slide_left_out);
		} else {
			ft.setCustomAnimations(R.anim.slide_right_in, R.anim.slide_right_out);
		}
		return ft;
	}

    
}
