package com.tz.filebrowse;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v4.util.LruCache;

public class ImageLoader {
	
	private static ImageLoader mImageLoader;
	
	/**
	 * 导包需要导入v4 兼容包兼容低版本
	 * 图片缓存核心类
	 */
	private static LruCache<String,Bitmap> mMemoryCache;
	
	
	private ImageLoader(){
		int maxMemory = (int) Runtime.getRuntime().maxMemory();
		int maxSize = maxMemory / 8;
		mMemoryCache = new LruCache<String, Bitmap>(maxSize){
			@Override
			protected int sizeOf(String key, Bitmap bitmap) {
				//重写此方法衡量每一张图片的大小，默认返回图片的数量大小
				return bitmap.getRowBytes()*bitmap.getHeight()/1024;
			}
		};
	}
	
	//单例模式 只实例化一次
	public static ImageLoader getInstance(){
		if(null == mImageLoader){
			mImageLoader = new ImageLoader();
		}
		return mImageLoader;
	}
	
	/**
	 * 将图片缓存LruCache中
	 */
	public void addBitmapToMemoryCache(String key,Bitmap bitmap){
		if(null == getBitmapFromMemoryCache(key)){
			mMemoryCache.put(key, bitmap);
		}
	}
	
	/**
	 * 从LruCache里面取出对应图片
	 * @return
	 */
	public Bitmap getBitmapFromMemoryCache(String key){
		return mMemoryCache.get(key);
	}
	
	/**
	 * 压缩图片
	 * @param imgPtah
	 * @param reqWidth
	 * @return
	 */
	public static Bitmap decodeBitmapFromResource(String imgPtah,int reqWidth){
		BitmapFactory.Options options = new BitmapFactory.Options();
		options.inJustDecodeBounds = true;
		BitmapFactory.decodeFile(imgPtah, options);
		int width = options.outWidth;
		int scaleSize = 1;
		if(width > reqWidth){
			int widthRatio = Math.round((float)width/(float)reqWidth);
			scaleSize = widthRatio;
		}
		options.inJustDecodeBounds = false;
		options.inSampleSize = scaleSize;
		return BitmapFactory.decodeFile(imgPtah, options);
	}

}
