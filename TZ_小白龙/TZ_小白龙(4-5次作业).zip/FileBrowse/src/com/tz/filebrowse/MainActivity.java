package com.tz.filebrowse;

import java.io.File;
import java.util.ArrayList;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends Activity {
	
	private ListView listview;
	private String rootPath;
	private ArrayList<FileModel> mList;
	private Bitmap fileBitmap,audioBitmap,videoBitmap,txtBitmap;
	private FileAdapter adapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		listview = (ListView) findViewById(R.id.listview);
		initPath();
	}

	private void createBitmap() {
		fileBitmap = BitmapFactory.decodeResource(getResources(),R.drawable.format_folder);
		audioBitmap = BitmapFactory.decodeResource(getResources(),R.drawable.format_music);
		videoBitmap = BitmapFactory.decodeResource(getResources(),R.drawable.format_media);
		txtBitmap = BitmapFactory.decodeResource(getResources(),R.drawable.format_text);
	}

	private void initPath() {
		//sd卡 挂载成功
		if(Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)){
			createBitmap();
			rootPath = Environment.getExternalStorageDirectory().getAbsolutePath();
			mList = new ArrayList<FileModel>();
			readPath(rootPath);
			listview.setOnItemClickListener(new OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> arg0, View arg1,
						int postion, long arg3) {
					FileModel model = mList.get(postion);
					File file = new File(model.getFilePath());
					if(file.isDirectory()){
						readPath(file.getAbsolutePath());
					}
				}
			});
		}else{
			Toast.makeText(this,"您的sd卡挂载异常",Toast.LENGTH_SHORT).show();
		}
	}
	
	/**
	 * 遍历文件
	 */
	private void readPath(String filePath){
		mList.clear();
		File file = new File(filePath);
		String parent = file.getParent();
		if(parent.equals(rootPath)){
			parent = rootPath;
		}
		FileModel modelBack = new FileModel("返回上级",fileBitmap,parent,false);
		mList.add(modelBack);
		
		File[] fileArray = file.listFiles();
		
		for(File fileItem:fileArray){
			FileModel model = new FileModel();
			String fileName = fileItem.getName();
			model.setFileName(fileName);
			model.setFilePath(fileItem.getAbsolutePath());
			
			//如果是文件夹
			fileName = fileName.toLowerCase();
			if(fileItem.isDirectory()){
				model.setBitmap(fileBitmap);
				model.setThumb(false);
			}else if(fileName.endsWith(".png")||fileName.endsWith(".jpg")||fileName.endsWith(".png")){
				model.setThumb(true);
				model.setBitmap(null);
			}else if(fileName.equals(".mp3")){
				model.setThumb(false);
				model.setBitmap(audioBitmap);
			}else if(fileName.equals(".mp4")){
				model.setThumb(false);
				model.setBitmap(videoBitmap);
			}else{
				model.setThumb(false);
				model.setBitmap(txtBitmap);
			}
			mList.add(model);
		}
		adapter = new FileAdapter(this, mList);
		listview.setAdapter(adapter);
	}

}
