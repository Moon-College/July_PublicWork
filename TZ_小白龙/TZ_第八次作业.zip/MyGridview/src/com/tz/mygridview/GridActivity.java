package com.tz.mygridview;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListView;

public class GridActivity extends Activity {
	
	/**
	 * @author wangwei
	 * This is a copy of the system's ListActivity
	 * Usage reference ListActivity
	 */
	protected GridView mGridView;

	protected GridAdapter mAdapter;

	private Handler mHandler = new Handler();

	private boolean mFinishedStart = false;

	protected void onListItemClick(ListView l, View v, int position, long id) {
	}

	private Runnable mRequestFocus = new Runnable() {
		public void run() {
			mGridView.focusableViewAvailable(mGridView);
		}
	};

	@Override
	protected void onRestoreInstanceState(Bundle state) {
		ensureList();
		super.onRestoreInstanceState(state);
	}

	@Override
	public void onContentChanged() {
		super.onContentChanged();
		mGridView = (GridView) findViewById(R.id.gridview);
		if (mGridView == null) {
			throw new RuntimeException(
					"Your content must have a GridView whose id attribute is "
							+ "'android.R.id.girdview'");
		}
		mGridView.setOnItemClickListener(mOnClickListener);
		if (mFinishedStart) {
			setGridAdapter(mAdapter);
		}
		mHandler.post(mRequestFocus);
		mFinishedStart = true;
	}

	public void setGridAdapter(GridAdapter adapter) {
		synchronized (this) {
			ensureList();
			mAdapter = adapter;
			mGridView.setAdapter(adapter);
		}
	}

	public void setSelection(int position) {
		mGridView.setSelection(position);
	}

	/**
	 * Get the position of the currently selected list item.
	 */
	public int getSelectedItemPosition() {
		return mGridView.getSelectedItemPosition();
	}

	public long getSelectedItemId() {
		return mGridView.getSelectedItemId();
	}

	public GridView getListView() {
		ensureList();
		return mGridView;
	}

	public GridAdapter getListAdapter() {
		return mAdapter;
	}

	private void ensureList() {
		if (mAdapter != null) {
			return;
		}
		setContentView(R.layout.girdview);
	}

	private AdapterView.OnItemClickListener mOnClickListener = new AdapterView.OnItemClickListener() {
		public void onItemClick(AdapterView<?> parent, View v, int position,
				long id) {
			onListItemClick((ListView) parent, v, position, id);
		}
	};

}
