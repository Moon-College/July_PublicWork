package com.tz.mygridview;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.os.Bundle;
import android.widget.SimpleAdapter;

public class MainActivity extends GridActivity{
	
	private List<Map<String,String>> mList;
	private GridBaseAdapter adapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		initData();
		adapter = new GridBaseAdapter(this, mList);
//		this.setListAdapter(adapter);
	}
	
	private void initData(){
		mList = new ArrayList<Map<String,String>>();
		for(int i = 0; i < 10; i++){
			HashMap<String, String> map = new HashMap<String, String>();
			map.put("tv", ""+i);
			mList.add(map);
		}
	}

}
