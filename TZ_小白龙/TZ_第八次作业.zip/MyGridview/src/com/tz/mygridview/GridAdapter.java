package com.tz.mygridview;

import android.widget.ListAdapter;

public interface GridAdapter extends ListAdapter{
	
	  public boolean areAllItemsEnabled();

	  boolean isEnabled(int position);

}
