package com.tz.mygridview;

import java.util.List;
import java.util.Map;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class GridBaseAdapter extends BaseAdapter{
	
	private List<Map<String,String>> mList;
	
	private LayoutInflater inflater;
	
	public GridBaseAdapter(){
	}
	
	public GridBaseAdapter(Context context,List<Map<String,String>> list){
		mList = list;
		inflater = LayoutInflater.from(context);
	}

	@Override
	public int getCount() {
		return mList.size();
	}

	@Override
	public Object getItem(int position) {
		return mList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View view = inflater.inflate(R.layout.grid_item, null);
		TextView textView = (TextView) view.findViewById(R.id.tv);
		textView.setText(mList.get(position).get("tv"));
		return view;
	}

}
