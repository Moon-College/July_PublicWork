package com.example.custom;

import java.util.Calendar;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.DialogInterface;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {

	private Button general, pop, progress, time, date, custom;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		initView();
	}

	private void initView() {
		general = (Button) findViewById(R.id.general);
		pop = (Button) findViewById(R.id.pop);
		progress = (Button) findViewById(R.id.progress);
		time = (Button) findViewById(R.id.time);
		date = (Button) findViewById(R.id.date);
		custom = (Button) findViewById(R.id.custom);
		general.setOnClickListener(this);
		pop.setOnClickListener(this);
		progress.setOnClickListener(this);
		time.setOnClickListener(this);
		date.setOnClickListener(this);
		custom.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.general:// 通用对话框
			generalDialog();
			break;
		case R.id.pop:
			popWidow();
			break;
		case R.id.progress:
			progressDialog();
			break;
		case R.id.time:
			timeDialog();
			break;
		case R.id.date:
			dateDialog();
			break;
		case R.id.custom:
			customDialog();
			break;
		case R.id.popbtn:
			Toast.makeText(this,"你被骗了吧", Toast.LENGTH_SHORT).show();
			break;
		}
	}

	private void generalDialog() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("通用对话框");
		builder.setMessage("通用对话框信息");
		builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.cancel();
			}
		});
		builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.cancel();
			}
		});
		builder.show();
	}

	private void popWidow() {
	
		View view = View.inflate(this, R.layout.popwindow, null);
		TextView textView = (TextView) view.findViewById(R.id.tv_info);
		Button popbtn = (Button) view.findViewById(R.id.popbtn);
		popbtn.setOnClickListener(this);
		PopupWindow window = new PopupWindow(view, 400, 400);
		window.setBackgroundDrawable(new BitmapDrawable());
		window.showAtLocation(pop, Gravity.CENTER, 200, 200);
		window.setTouchable(true);
		window.setFocusable(true);
		String info = textView.getText().toString();
		Toast.makeText(this, info, Toast.LENGTH_SHORT).show();
	}

	private void progressDialog() {
		ProgressDialog pro = new ProgressDialog(this);
		pro.setMessage("正在加载");
		pro.show();
	}

	private void timeDialog() {
		Calendar c = Calendar.getInstance();
		TimePickerDialog timeDialog = new TimePickerDialog
				(this, new OnTimeSetListener() {
					@Override
					public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
						Toast.makeText(MainActivity.this,""+hourOfDay, Toast.LENGTH_SHORT).show();
					}
				}, c.HOUR_OF_DAY, c.MINUTE,true);
		timeDialog.show();
	}

	private void dateDialog() {
		Calendar c = Calendar.getInstance();
		DatePickerDialog dateDialog = new DatePickerDialog
				(this, new OnDateSetListener() {
					@Override
					public void onDateSet(DatePicker view, int year, int monthOfYear,
							int dayOfMonth) {
						Toast.makeText(MainActivity.this,""+year, Toast.LENGTH_SHORT).show();
					}
				}, 2014, 5, 20);
		dateDialog.show();
	}

	private void customDialog() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		View view = View.inflate(this, R.layout.popwindow, null);
		Button popbtn = (Button) view.findViewById(R.id.popbtn);
		popbtn.setOnClickListener(this);
		builder.setView(view);
		builder.show();
	}

}
