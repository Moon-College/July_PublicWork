package com.example.tz_715_java;

import android.os.Bundle;
import android.provider.ContactsContract.CommonDataKinds.Organization;
import android.app.Activity;
import android.view.Menu;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		LinearLayout layout = new LinearLayout(this);
		LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
//		layoutParams.setMargins(10, 10, 10, 0);
		layout.setLayoutParams(layoutParams);
		
		layout.setOrientation(LinearLayout.HORIZONTAL);
		EditText editText = new EditText(this);
		Button button = new Button(this);
		//设置摆放位置
		LinearLayout.LayoutParams params = new LayoutParams(0, 50, 3);
		LinearLayout.LayoutParams params1 = new LayoutParams(0, 50, 1);
		//设置外间距
		params.setMargins(10, 10, 10, 0);
		params1.setMargins(10, 10, 10, 0);
		editText.setLayoutParams(params);
		editText.setHint("请输入需要查询的数据");
		button.setLayoutParams(params1);
		button.setText("查询");
		layout.addView(editText);
		layout.addView(button);
		setContentView(layout);
	}

}
