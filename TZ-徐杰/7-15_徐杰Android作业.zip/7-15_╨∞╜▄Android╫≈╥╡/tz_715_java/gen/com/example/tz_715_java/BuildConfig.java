/** Automatically generated file. DO NOT MODIFY */
package com.example.tz_715_java;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}