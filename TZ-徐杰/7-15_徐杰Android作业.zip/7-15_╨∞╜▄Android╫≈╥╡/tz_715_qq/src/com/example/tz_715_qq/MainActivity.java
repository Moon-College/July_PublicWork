package com.example.tz_715_qq;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.zip.Inflater;

import android.os.Bundle;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends Activity {
	private ListView lv_Tool;
	private ListView lv_service;
	// ArrayList<HashMap<String, String>> list_tool = new
	// ArrayList<HashMap<String, String>>();
	ArrayList<HashMap<String, String>> list_service = new ArrayList<HashMap<String, String>>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main);
		initView();
		initdate();
		lv_Tool.setAdapter(new Myadapter());
		lv_service.setAdapter(new Myadapter());
	}

	/**
	 * 设置数据
	 */
	private void initdate() {
		HashMap<String, String> map;
		for (int i = 0; i < 10; i++) {
			map = new HashMap<String, String>();
			map.put("img", R.drawable.qun + "");
			map.put("name", "游戏" + i);
			list_service.add(map);
		}

	}

	/**
	 * 初始化组件
	 */
	private void initView() {
		lv_Tool = (ListView) findViewById(R.id.lv_Tool);
		lv_service = (ListView) findViewById(R.id.lv_service);
	}

	class Myadapter extends BaseAdapter {

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return list_service.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return list_service.get(position);
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
			convertView = LayoutInflater.from(MainActivity.this).inflate(R.layout.listview_item, null);
		HashMap<String, String > map = list_service.get(position);
		Integer integer = Integer.parseInt(map.get("img")) ;
		Drawable drawable = getResources().getDrawable(integer);
		ImageView imageView = (ImageView) convertView.findViewById(R.id.img_tag);
		TextView textView = (TextView) convertView.findViewById(R.id.tv_name);
		textView.setText(map.get("name"));
		imageView.setImageResource(integer);
		return convertView;
	}
	}

}
