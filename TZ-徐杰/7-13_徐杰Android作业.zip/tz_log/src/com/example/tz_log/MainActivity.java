package com.example.tz_log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import android.R.array;
import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.widget.TextView;

public class MainActivity extends Activity {
	private TextView textView;
	String LOG_TAG = "LOG_TAG";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		textView = (TextView) findViewById(R.id.textview);
		Log.i(LOG_TAG, "干货快快来~");
		getMessageFromLog();
	}

	private void getMessageFromLog() {

		ArrayList<String> arrayList = new ArrayList<String>();
		arrayList.add("logcat");
		arrayList.add("-d");
		arrayList.add("-s");
		arrayList.add("LOG_TAG");
		String[] str = new String[arrayList.size()];
		try {
			//获取当前运行的线程执行操作
			Process process = Runtime.getRuntime().exec(arrayList.toArray(str));
			//得到流
			InputStream is =process.getInputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(is));
			StringBuffer sb = new StringBuffer();
			while(reader.readLine()!=null)
			{
				sb.append(reader.readLine());
				
			}
			textView.setText(sb.toString());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
