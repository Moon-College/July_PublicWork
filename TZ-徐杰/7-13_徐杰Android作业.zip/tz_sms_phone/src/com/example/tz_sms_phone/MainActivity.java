package com.example.tz_sms_phone;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity {
	private Button phone;
	private Button sms;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		initView();

	}

	private void initView() {

		phone = (Button) findViewById(R.id.phone);
		sms = (Button) findViewById(R.id.sms);
	}

	public void phone(View view) {
		Uri uri = Uri.parse("tel://5560");
		//打电话
		Intent intent = new Intent(Intent.ACTION_CALL, uri);
		//跳转打电话界面
		//Intent intent = new Intent(Intent.ACTION_CALL_BUTTON);
		startActivity(intent);

	}

	public void sms(View view) {
		Uri uri = Uri.parse("smsto://5560");
		//跳转发信息界面
		Intent intent = new Intent(Intent.ACTION_SENDTO,uri);
		startActivity(intent);
	}

}
